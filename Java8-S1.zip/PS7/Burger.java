package com.PS7;

public interface Burger {
          String makeBurger();
}
