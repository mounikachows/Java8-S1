package com.PS1;

import java.util.Scanner;

public class BookService {
	public static Book[] createBooks(int n) {
        Scanner scanner = new Scanner(System.in);
        Book[] books = new Book[n];

        for (int i = 0; i < n; i++) {
            System.out.println("Enter title for book " + (i + 1) + ":");
            String title = scanner.nextLine();

            System.out.println("Enter price for book " + (i + 1) + ":");
            float price = scanner.nextFloat();

            scanner.nextLine(); 

            Book book = new Book();
            book.setBooktitle(title);
            book.setBookprice(price);

            books[i] = book;
        }

        return books;
    }

    public static void showBooks(Book[] books) {
        System.out.println("Book Title   Price");
        for (Book book : books) {
            System.out.printf("%-12s Rs %.2f\n",book.getBooktitle(),book.getBookprice());
        }
    }


}
