package com.PS1;

import java.util.Scanner;

public class BookTest {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the number of books:");
        int n = scanner.nextInt();
        scanner.nextLine(); 
        
        Book[] books = BookService.createBooks(n);

        System.out.println("Books:");
        BookService.showBooks(books);

        scanner.close();
    }



	}


