package com.PS1;


	import java.util.Scanner;

	public class Book {
		
		private String Booktitle;
		private float Bookprice;
		public Book() {
			super();
			// TODO Auto-generated constructor stub
		}
		public String getBooktitle() {
			return Booktitle;
		}
		public void setBooktitle(String booktitle) {
			Booktitle = booktitle;
		}
		public float getBookprice() {
			return Bookprice;
		}
		public void setBookprice(float bookprice) {
			Bookprice = bookprice;
		}
		
		}
		
		
		
	