package com.PS1;

public class Rectangle {
	private float length;
	private float breadth;
	
	public Rectangle(float length, float breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
	}


	public float getLength() {
		return length;
	}

	public void setLength(float length) {
		this.length = length;
	}

	public float getBreadth() {
		return breadth;
	}

	public Rectangle() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setBreadth(float breadth) {
		this.breadth = breadth;
	}
	
	
	public double calArea() {
        return length * breadth;
    }
	
	public void dispInfo() {
        System.out.println("Length: " + length);
        System.out.println("Breadth: " + breadth);
        System.out.println("Area: " + calArea());
    }
	
}
