package com.PS1;

import java.util.Scanner;

public class TestRectangle {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		  //      Rectangle[] rec  = new Rectangle[1];

//		        for (int i = 0; i < rec.length; i++) {
//		            System.out.println("Enter length for rectangle " + (i + 1) + ":");
//		            float length = scanner.nextFloat();
		//
//		            System.out.println("Enter breadth for rectangle " + (i + 1) + ":");
//		            float breadth = scanner.nextFloat();
		//
//		            rec[i] = new Rectangle(length, breadth);
//		        }
		//
//		        System.out.println("Areas of the rec:");
//		        for (int i = 0; i < rec.length; i++) {
//		            System.out.println("Rectangle " + (i + 1) + ":");
//		            rec[i].dispInfo();
//		            System.out.println();
//		        }
		        
		        // For Length * Width
		        
		        RectangleWL[] rec  = new RectangleWL[1];
		        
		        for (int i = 0; i < rec.length; i++) {
		            System.out.println("Enter length for rectangle " + (i + 1) + ":");
		            float length = scanner.nextFloat();

		            System.out.println("Enter width for rectangle " + (i + 1) + ":");
		            float width = scanner.nextFloat();

		            rec[i] = new RectangleWL();
		            rec[i].setLength(length);
		            rec[i].setWidth(width);
		        }

		        
		        System.out.println("Areas of the rectangles:");
		        for (int i = 0; i < rec.length; i++) {
		            rec[i].dispInfo();
		            System.out.println();
		        }


	}

}
