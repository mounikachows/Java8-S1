package com.PS1;

public class RectangleWL {
	private float length;
	private float width;
	
	

	public RectangleWL() {
		super();
		// TODO Auto-generated constructor stub
	}

	public float getLength() {
		return length;
	}

	public void setLength(float length) {
		 if (length > 0.0 && length < 20.0) {
			 this.length = length;
		 }  
	       else {
	    	   System.out.println("Length must be a positive number.");
	        }        
	}

	public float getWidth() {
		return width;
	}

	public void setWidth(float width) {
		if (width > 0.0 && width < 20.0) {
			 this.width = width;
		 }  
	       else {
	    	   System.out.println("Length must be a positive number.");
	        }        
	}
	
	
	 public double calArea() {
	        return length * width;
	    }
	 
	 public void dispInfo() {
	        System.out.println("Length: " + length);
	        System.out.println("Breadth: " + width);
	        System.out.println("Area: " + calArea());
	    }

}



