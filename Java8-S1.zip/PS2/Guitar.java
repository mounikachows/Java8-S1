package com.PS2;
public class Guitar implements Instrument {

	@Override
	public
	void play() {
		System.out.println("Guitar is playing tin tin tin");
	}
}



