package com.PS2;

public class Flute implements Instrument {

	@Override
	public
	void play() {
		System.out.println("Flute is playing toot toot toot toot");
	}


}
