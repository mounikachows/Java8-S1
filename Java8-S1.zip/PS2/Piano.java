package com.PS2;


public class Piano implements Instrument{

	@Override
	public
	void play() {
		System.out.println("Piano is playing tan tan tan tan");
	}
}



