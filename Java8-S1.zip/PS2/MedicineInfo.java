package com.PS2;

public interface MedicineInfo {
	void displayLabel();
}
