package com.PS2;

public interface Instrument {
	void play();
}
