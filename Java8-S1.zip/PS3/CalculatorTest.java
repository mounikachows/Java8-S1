package com.PS3;

public class CalculatorTest {

	public static void main(String[] args) {
		IntegerMath addition=(a,b)-> a+b;
		IntegerMath subtraction=(a,b)-> a-b;
		IntegerMath multiplication=(a,b)-> a*b;
		IntegerMath division=(a,b)->(b!=0)?a/b:0;
		
		System.out.println("Addition : "+addition.operation(3, 1));
		System.out.println("Subtraction : "+subtraction.operation(3, 1));
		System.out.println("Multiplication : "+multiplication.operation(3, 5));
		System.out.println("Division : "+division.operation(8, 4));
		
	}

	}


